using Npgsql;
using System.Data.Odbc;
using System.Data;

namespace Univer_UnitTestBillinG
{
    [TestClass]
    public class UniverDataGetTest
    {
        NpgsqlConnection npgsqlConnection = new NpgsqlConnection("Server=localhost;Port=5432;User ID=University_Base;Password=6708;Database=university");
        NpgsqlCommand npgsqlCommand;
        NpgsqlDataAdapter npgsqlAdapter;
        public DataTable datatable;

        [TestMethod]
        public void SelectTestTrue()
        {
            string query = $"SELECT faculty FROM university.faculties WHERE facultid = @Facultid";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Facultid", 101);
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
            Assert.AreEqual($"��������������", GetData($"SELECT faculty FROM university.faculties WHERE facultid = {101}", "faculty").ToString());
        }

        [TestMethod]
        public void InsertTestTrue()
        {
            string query = $"INSERT INTO university.faculties VALUES (@Facultid, @Faculty)";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Facultid", 783828);
            npgsqlCommand.Parameters.AddWithValue("@Faculty", "������������");
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
        }

        [TestMethod]
        public void UpdateTestTrue()
        {
            string query = "UPDATE university.faculties SET faculty = @Faculty WHERE facultid = @Facultid";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Faculty", "�����������������");
            npgsqlCommand.Parameters.AddWithValue("@Facultid", 2090817);
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
        }

        [TestMethod]
        public void TestDelTrue()
        {
            string query = "DELETE FROM university.faculties WHERE facultid = @Facultid";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Facultid", 2090817);
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
        }

        [TestMethod]
        public void TestDelFail()
        {
            string query = "DELETE FROM university.faculties WHERE facultid = @Facultid";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Facultid", 2002020);
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
            Assert.AreEqual($"2002020", GetData($"SELECT buyer_id = {2002020} FROM buyers", "buyer_id").ToString());
        }

        string GetData(string command, string column)
        {
            string query = command;
            npgsqlAdapter = new NpgsqlDataAdapter(query, npgsqlConnection);
            npgsqlConnection.Open();
            datatable = new DataTable();
            npgsqlAdapter.Fill(datatable);
            npgsqlConnection.Close();
            return datatable.Rows[0][$"{column}"].ToString();
        }
    }
}
