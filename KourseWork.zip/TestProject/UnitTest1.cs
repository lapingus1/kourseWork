using Npgsql;

namespace TestProject
{
    [TestClass]
    public class ConnectionUnitTest
    {
        [TestMethod]
        public void TestOneConnectFail()
        {
            NpgsqlConnection npgsqlConnection = new NpgsqlConnection("Server=localhost;Port=5432;User ID=University_Base;Password=670748;Database=univertsity"); 
            npgsqlConnection.Open();
        }
        [TestMethod]
        public void TestOneConnectTrue()
        {
            NpgsqlConnection npgsqlConnection = new NpgsqlConnection("Server=localhost;Port=5432;User ID=University_Base;Password=6708;Database=university");
            npgsqlConnection.Open();
        }

    }
}