using Npgsql;
using System.Data;

namespace Univer_UnitTest
{
    [TestClass]
    public class AuthorizationUnitTest
    {
        NpgsqlConnection npgsqlConnection = new NpgsqlConnection("Server=localhost;Port=5432;User ID=University_Base;Password=6708;Database=university");
        NpgsqlCommand npgsqlCommand;
        NpgsqlDataAdapter npgsqlAdapter;
        public DataTable datatable;

        [TestMethod]
        public void AuthorizationPasswordTrue()
        {
            string logi = "admin";
            string query = $"SELECT password = @Password FROM university.logins WHERE login = '{logi}'";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Password", "bgnjm");
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
            Assert.AreEqual($"bgnjm", GetUser($"SELECT password FROM university.logins WHERE login = '{logi}'").ToString());
        }

        [TestMethod]
        public void AuthorizationPasswordFals()
        {
            string logi = "admin";
            string query = $"SELECT password = @Password FROM university.logins WHERE login = '{logi}'";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Password", "bgnjm");
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
            Assert.AreEqual($"lilpeep", GetUser($"SELECT password FROM university.logins WHERE login = '{logi}'").ToString());
        }

        [TestMethod]
        public void AuthorizationLoginTrue()
        {
            string boby = "bgnjm";
            string query = $"SELECT login = @Login FROM university.logins WHERE password = '{boby}'";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Login", "admin");
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
            Assert.AreEqual($"admin", GetLogin($"SELECT login FROM university.logins WHERE password = '{boby}'").ToString());
        }

        [TestMethod]
        public void AuthorizationLoginFals()
        {
            string boby = "bgnjm";
            string query = $"SELECT login = @Login FROM university.logins WHERE password = '{boby}'";
            npgsqlCommand = new NpgsqlCommand(query, npgsqlConnection);
            npgsqlCommand.Parameters.AddWithValue("@Login", "admin");
            npgsqlConnection.Open();
            npgsqlCommand.ExecuteNonQuery();
            npgsqlConnection.Close();
            Assert.AreEqual($"killya", GetLogin($"SELECT login FROM university.logins WHERE password = '{boby}'").ToString());
        }
        string GetUser(string text)
        {
            string query = text;
            npgsqlAdapter = new NpgsqlDataAdapter(query, npgsqlConnection);
            npgsqlConnection.Open();
            datatable = new DataTable();
            npgsqlAdapter.Fill(datatable);
            npgsqlConnection.Close();
            return datatable.Rows[0]["password"].ToString();
        }
        string GetLogin(string text)
        {
            string query = text;
            npgsqlAdapter = new NpgsqlDataAdapter(query, npgsqlConnection);
            npgsqlConnection.Open();
            datatable = new DataTable();
            npgsqlAdapter.Fill(datatable);
            npgsqlConnection.Close();
            return datatable.Rows[0]["login"].ToString();
        }
    }
}